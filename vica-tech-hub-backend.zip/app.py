"""VICA TECH HUB - Render-ready Bottle + SQLite API."""
import os
import json
import sqlite3
import hashlib
import secrets
from datetime import datetime, timezone
from bottle import Bottle, request, response

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "database.db")
FRONTEND_ORIGIN = os.environ.get("FRONTEND_ORIGIN", "*")

app = Bottle()


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def connect():
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys = ON")
    return db


def init_db():
    with connect() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS users(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          email TEXT NOT NULL UNIQUE,
          phone TEXT,
          password_hash TEXT NOT NULL,
          is_admin INTEGER NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS categories(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL UNIQUE,
          slug TEXT NOT NULL UNIQUE
        );
        CREATE TABLE IF NOT EXISTS products(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          category_id INTEGER,
          brand TEXT NOT NULL,
          description TEXT NOT NULL,
          price INTEGER NOT NULL CHECK(price >= 0),
          old_price INTEGER DEFAULT 0,
          stock INTEGER NOT NULL DEFAULT 0,
          image TEXT,
          rating REAL DEFAULT 0,
          created_at TEXT NOT NULL,
          FOREIGN KEY(category_id) REFERENCES categories(id)
        );
        CREATE TABLE IF NOT EXISTS orders(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER,
          customer_name TEXT NOT NULL,
          email TEXT NOT NULL,
          phone TEXT NOT NULL,
          total_amount INTEGER NOT NULL,
          delivery_address TEXT NOT NULL,
          payment_method TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'Pending',
          created_at TEXT NOT NULL,
          FOREIGN KEY(user_id) REFERENCES users(id)
        );
        CREATE TABLE IF NOT EXISTS order_items(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          order_id INTEGER NOT NULL,
          product_id INTEGER,
          product_name TEXT NOT NULL,
          quantity INTEGER NOT NULL CHECK(quantity > 0),
          unit_price INTEGER NOT NULL,
          FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE,
          FOREIGN KEY(product_id) REFERENCES products(id)
        );
        CREATE TABLE IF NOT EXISTS reviews(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER,
          product_id INTEGER NOT NULL,
          customer_name TEXT NOT NULL,
          rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
          review TEXT NOT NULL,
          created_at TEXT NOT NULL,
          FOREIGN KEY(user_id) REFERENCES users(id),
          FOREIGN KEY(product_id) REFERENCES products(id)
        );
        CREATE TABLE IF NOT EXISTS wishlist(
          user_id INTEGER NOT NULL,
          product_id INTEGER NOT NULL,
          created_at TEXT NOT NULL,
          PRIMARY KEY(user_id, product_id),
          FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
          FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
        );
        """)

        categories = [
            "Laptops", "Phones", "Computers", "Accessories", "Audio",
            "Storage", "Gaming", "Printers", "Networking", "Tablets", "Monitors"
        ]
        for name in categories:
            slug = name.lower().replace(" ", "-")
            db.execute("INSERT OR IGNORE INTO categories(name,slug) VALUES(?,?)", (name, slug))

        # Seed a few products once, so a fresh deployment has something to display.
        count = db.execute("SELECT COUNT(*) AS n FROM products").fetchone()["n"]
        if count == 0:
            seeds = [
                ("HP 15 Laptop", "Laptops", "HP", "Reliable everyday laptop for work, school and business.", 650000, 700000, 10, "images/hp-laptop.jpg", 4.5),
                ("Samsung Galaxy A55", "Phones", "Samsung", "Modern Android smartphone with a bright display and strong battery life.", 520000, 560000, 15, "images/samsung-a55.jpg", 4.6),
                ("Logitech Wireless Mouse", "Accessories", "Logitech", "Comfortable wireless mouse for office and home use.", 18000, 22000, 30, "images/logitech-mouse.jpg", 4.4),
                ("Kingston 1TB SSD", "Storage", "Kingston", "Fast 1TB solid-state storage for laptops and desktops.", 95000, 110000, 20, "images/kingston-ssd.jpg", 4.7),
                ("Anker Power Bank 20000mAh", "Accessories", "Anker", "High-capacity portable charging for phones and tablets.", 65000, 75000, 25, "images/anker-powerbank.jpg", 4.5),
            ]
            for row in seeds:
                name, category, brand, desc, price, old_price, stock, image, rating = row
                cat = db.execute("SELECT id FROM categories WHERE name=?", (category,)).fetchone()
                db.execute("""INSERT INTO products
                    (name,category_id,brand,description,price,old_price,stock,image,rating,created_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?)""",
                    (name, cat["id"], brand, desc, price, old_price, stock, image, rating, utc_now()))


def json_response(data, status=200):
    response.content_type = "application/json; charset=UTF-8"
    response.status = status
    return json.dumps(data)


def body_json():
    try:
        return request.json or {}
    except Exception:
        return {}


@app.hook("after_request")
def cors_headers():
    response.set_header("Access-Control-Allow-Origin", FRONTEND_ORIGIN)
    response.set_header("Vary", "Origin")
    response.set_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
    response.set_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
    response.set_header("Access-Control-Max-Age", "86400")


@app.route("/api/<path:path>", method="OPTIONS")
def options(path):
    return json_response({"ok": True})


@app.get("/")
def home():
    return json_response({"ok": True, "service": "VICA TECH HUB API", "message": "API is running"})


@app.get("/api/health")
def health():
    return json_response({"ok": True, "service": "VICA TECH HUB API"})


@app.get("/api/categories")
def get_categories():
    with connect() as db:
        rows = db.execute("SELECT id,name,slug FROM categories ORDER BY name").fetchall()
    return json_response([dict(row) for row in rows])


@app.get("/api/products")
def get_products():
    q = (request.query.get("q") or "").strip()[:100]
    category = (request.query.get("category") or "").strip()[:80]
    sql = """SELECT p.id,p.name,p.brand,p.description,p.price,p.old_price,p.stock,p.image,p.rating,
             c.name AS category FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE 1=1"""
    args = []
    if q:
        like = "%" + q + "%"
        sql += " AND (p.name LIKE ? OR p.brand LIKE ? OR p.description LIKE ?)"
        args.extend([like, like, like])
    if category:
        sql += " AND c.name = ?"
        args.append(category)
    sql += " ORDER BY p.created_at DESC LIMIT 200"
    with connect() as db:
        rows = db.execute(sql, args).fetchall()
    return json_response([dict(row) for row in rows])


@app.get("/api/products/<product_id:int>")
def get_product(product_id):
    with connect() as db:
        row = db.execute("""SELECT p.*,c.name AS category FROM products p
            LEFT JOIN categories c ON c.id=p.category_id WHERE p.id=?""", (product_id,)).fetchone()
    if not row:
        return json_response({"error": "Product not found"}, 404)
    return json_response(dict(row))


@app.post("/api/products")
def create_product():
    data = body_json()
    required = ["name", "category", "brand", "description", "price"]
    if any(not str(data.get(k, "")).strip() for k in required):
        return json_response({"error": "Missing required product fields"}, 400)
    try:
        price, stock = int(data["price"]), int(data.get("stock", 0))
        old_price = int(data.get("old_price", 0) or 0)
        if price < 0 or stock < 0 or old_price < 0:
            raise ValueError()
    except (ValueError, TypeError):
        return json_response({"error": "Price and stock must be valid non-negative integers"}, 400)
    with connect() as db:
        cat = db.execute("SELECT id FROM categories WHERE name=?", (data["category"],)).fetchone()
        if not cat:
            return json_response({"error": "Unknown category"}, 400)
        cur = db.execute("""INSERT INTO products(name,category_id,brand,description,price,old_price,stock,image,rating,created_at)
            VALUES(?,?,?,?,?,?,?,?,?,?)""",
            (data["name"].strip()[:160], cat["id"], data["brand"].strip()[:80],
             data["description"].strip()[:4000], price, old_price, stock,
             str(data.get("image", ""))[:1000], 0, utc_now()))
        product_id = cur.lastrowid
    return json_response({"id": product_id, "message": "Product created"}, 201)


@app.post("/api/register")
def register():
    data = body_json()
    name, email, password = (str(data.get(k, "")).strip() for k in ("name", "email", "password"))
    phone = str(data.get("phone", "")).strip()
    if len(name) < 2 or "@" not in email or len(password) < 8:
        return json_response({"error": "Provide a name, valid email and password of at least 8 characters"}, 400)
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 200_000)
    stored_hash = salt.hex() + "$" + digest.hex()
    try:
        with connect() as db:
            cur = db.execute("INSERT INTO users(name,email,phone,password_hash,created_at) VALUES(?,?,?,?,?)",
                (name[:120], email.lower()[:254], phone[:30], stored_hash, utc_now()))
            user_id = cur.lastrowid
    except sqlite3.IntegrityError:
        return json_response({"error": "Email already registered"}, 409)
    return json_response({"id": user_id, "message": "Account created"}, 201)


@app.post("/api/orders")
def create_order():
    data = body_json()
    required = ["name", "email", "phone", "address", "payment_method", "items"]
    if any(not data.get(k) for k in required):
        return json_response({"error": "Missing required order information"}, 400)
    items = data["items"]
    if not isinstance(items, list) or not items or len(items) > 100:
        return json_response({"error": "Order must contain between 1 and 100 items"}, 400)
    try:
        with connect() as db:
            normalized, total = [], 0
            for item in items:
                product_id, qty = int(item["product_id"]), int(item["quantity"])
                if qty < 1 or qty > 100:
                    raise ValueError("Invalid quantity")
                product = db.execute("SELECT id,name,price,stock FROM products WHERE id=?", (product_id,)).fetchone()
                if not product or product["stock"] < qty:
                    return json_response({"error": "Product unavailable or insufficient stock"}, 409)
                total += product["price"] * qty
                normalized.append((product, qty))
            cur = db.execute("""INSERT INTO orders(user_id,customer_name,email,phone,total_amount,delivery_address,payment_method,status,created_at)
                VALUES(NULL,?,?,?,?,?,?,?,?)""",
                (str(data["name"])[:120], str(data["email"])[:254], str(data["phone"])[:30],
                 total, str(data["address"])[:1000], str(data["payment_method"])[:80],
                 "Pending", utc_now()))
            order_id = cur.lastrowid
            for product, qty in normalized:
                db.execute("INSERT INTO order_items(order_id,product_id,product_name,quantity,unit_price) VALUES(?,?,?,?,?)",
                           (order_id, product["id"], product["name"], qty, product["price"]))
                db.execute("UPDATE products SET stock=stock-? WHERE id=?", (qty, product["id"]))
    except (ValueError, KeyError, TypeError):
        return json_response({"error": "Invalid order item data"}, 400)
    return json_response({"order_id": order_id, "total": total, "status": "Pending"}, 201)


# Initialize schema whenever the server starts, including under Gunicorn.
init_db()
