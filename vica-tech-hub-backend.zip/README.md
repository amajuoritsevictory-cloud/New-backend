# VICA TECH HUB — Render Backend

This folder is a standalone Python/Bottle API prepared for Render.

## 1. Upload to GitHub
Create a new GitHub repository, for example `vica-tech-hub-backend`, and put **these files at the repository root**:

```text
app.py
requirements.txt
render.yaml
.gitignore
README.md
```

Do not put them inside another `backend/` folder unless you configure Render's Root Directory accordingly.

## 2. Deploy on Render
Create a **Web Service** from the GitHub repository.

Use:

- Runtime: Python 3
- Build Command: `pip install -r requirements.txt`
- Start Command: `gunicorn --bind 0.0.0.0:$PORT app:app`
- Plan: Free

If Render reads `render.yaml`, these settings are already included.

## 3. CORS
Add an environment variable on Render:

```text
FRONTEND_ORIGIN=https://YOUR-FRONTEND-DOMAIN.com
```

For temporary testing, leaving it unset allows `*`. Before a real launch, set it to the exact frontend origin.

## 4. Test after deployment
Open:

```text
https://YOUR-RENDER-SERVICE.onrender.com/api/health
```

You should receive JSON similar to:

```json
{"ok": true, "service": "VICA TECH HUB API"}
```

Then test:

```text
https://YOUR-RENDER-SERVICE.onrender.com/api/products
```

## Important SQLite note
Render's free service uses an ephemeral filesystem. This means the local SQLite database can be lost after certain restarts/redeployments. This backend is suitable for learning, demos, and early testing. For a production store, move the database to persistent PostgreSQL or another managed database before relying on it for real orders.

## Existing frontend
Set your frontend API base URL to the Render service URL, for example:

```javascript
const API_BASE_URL = "https://YOUR-RENDER-SERVICE.onrender.com";
```
